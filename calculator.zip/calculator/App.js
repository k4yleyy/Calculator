import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';


export default function App() {
  const[display, setDisp] = React.useState(0);
  const[operand1, setOperand1] = React.useState (0);
  const[operation, setOperation] = React.useState ('');
  const pressNum = (num) => {
         setDisp(10*display + num);
  }
  const pressOp = (op) => {
    setOperand1(display);
    setOperation(op);
    setDisp(0);
  }
  const clear = () => {
    setDisp(0);
    setOperation('');
    setOperation(0);
  };
  const calculate = () => {
    if (operation === ('*')) {
      setDisp (operand1 * display);
    } else if (operation === ('-')) {
      setDisp (operand1 - display)
    } else if (operation === ('+')) {
      setDisp (operand1 + display)
    } else if (operation === ('/')) {
      setDisp (operand1 / display)
    } else if (operation === ('^')) {
      setDisp (operand1 ** display)
    }
  }
  const pi = () => {
    setDisp (display * Math.PI)
  }
  const sqrt= () => {
    setDisp (Math.sqrt(display))
  }
  const log= () => {
    setDisp (Math.log10(display))
  }
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        {display}
      </Text>
      <View style={styles.row}> 
        <Button title="   ^   " 
        onPress={()=>pressOp("^")}
        />
        <Button title="  π  " 
        onPress={pi}
        />
        <Button title="  √   " 
        onPress={sqrt}
        />
        <Button title=" log " 
        onPress={log}
        />
      </View>
      <View style={styles.row}> 
        <Button title="   1   " 
        onPress={()=>pressNum(1)} />
        <Button title="   2   " 
        onPress={()=>pressNum(2)} />
        <Button title="   3   " 
        onPress={()=>pressNum(3)} />
        <Button 
        title="   +   "
        onPress={()=>pressOp("+")} 
        color= "#c4c3c7"
        />
      </View>
      <View style={styles.row}> 
        <Button title="   4   " 
        onPress={()=>pressNum(4)} />
        <Button title="   5   " 
        onPress={()=>pressNum(5)} />
        <Button title="   6   " 
        onPress={()=>pressNum(6)} />
        <Button 
        title="   -   " 
        onPress={()=>pressOp("-")}
        color= "#c4c3c7"
        />
      </View>
       <View style={styles.row}> 
        <Button title="   7   " 
        onPress={()=>pressNum(7)} />
        <Button title="   8   " 
        onPress={()=>pressNum(8)} />
        <Button title="   9   "
        onPress={()=>pressNum(9)}  />
        <Button 
        title="   *   " 
        onPress={()=>pressOp("*")}
        color= "#c4c3c7"
        />
      </View>
      <View style={styles.row}> 
        <Button 
        title="   C   " 
        onPress= {clear}
        color= "#ff7070"
        />
        <Button title="   0   "
        onPress={()=>pressNum(0)} />
        <Button 
        title="   =   " 
        color= "#ff7070"
        onPress= {calculate}
        />
        <Button 
        title="   /   " 
        onPress={()=>pressOp("/")}
        color= "#c4c3c7"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
    borderWidth: 1,
    padding: 8,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
  }
});
